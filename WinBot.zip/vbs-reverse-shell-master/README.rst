Description
===========

Collection of VBS reverse shells

VBS reverse shells are a bit tricky because there's no easy way to interact
with raw sockets from VBS natively on Windows. However, since powershell
isn't always available on the target computer, VBS reverse shells have a real
value. So if you need them, they're here!

How to use it
=============

- Start the python server on your machine.
- Adapt one of the VBS files with your IP address.
- Drop this VBS file onto the target and execute it.

Dependencies
============

- Python3

License
=======

This program is under the GPLv3 License.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
